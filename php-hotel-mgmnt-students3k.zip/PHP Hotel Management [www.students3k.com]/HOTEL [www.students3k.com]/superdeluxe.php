<html>
<head>
	<title>superdeluxe</title>
</head>
<body>
	<center><font color=purple size=6><a href=superdeluxe1.php>superdeluxe</a></font></center>
	<img src="image/hsuites.jpg" height=400 width=750>
	<font color=purple size=3>
	<pre>
		luxuriously furnished room having a sofa cum bed
		for an extra adult or child with wall to wall carpet. this rooms are attached
		with private windows over looking the plam view garden.
	</font>
	</pre>
	<a href=accomodation.php>home</a>
</body>
</html>