<html>
<head>
	<title>BANQUET & CONFERENCE</title>
	<link rel="stylesheet" type="text/css" href="link.html">
</head>
<body bgcolor="#fff2e5">
<?php
	include "index.php";
?>
<br><br>
<center><font color=choco size=4><b><i><u>BANQUET & CONFERENCE</u></i></b></font></center>
<br><br>
<center><font color="#7c0000" size=4>Banquet:Celebration and Conference:Crystal</font></center>
<table>
<tr>
	<td><a href=b1.php target=_blank><img src="image/hmarriage.jpg" width=125 height=150></a></td>
	<td>The<font color="#7c0000">PARAS</font>hotel offers a selection of facalities for meetings in Amreli for 
		every occasion whether for a conference, business seminar,business associates over lunch or dinner.</td>
	<td><a href=b2.php target=_blank><img src="image/hmeetings.jpg" width=125 height=150></a></td>
</tr>
<tr>
	<td><font color="#7c0000">Celebration</font></td>
	<td></td>
	<td><font color="#7c0000">U-shape</font></td>
</tr>
<tr>
	<td>&nbsp;</td>
	<td>The<font color="#7c0000">PARAS</font>hotel Banquet parties are arranged in 120 persons in a cazy atmosphere
	and marriage parties are arranged in our pool garden by our all facalities</td>
	<td>&nbsp;</td>
</tr>
</table>
<table>
<tr>
	<td><a href=b3.php target=_blank><img src="image/meeting2.jpg" width=125 height=150></a></td>
	<td>Our proffessional & exprienced staff shell be always available to assist you to the last moment in helping
	you enduting success in any banquet & meetings.</td>
	<td><a href=b4.php target=_blank><img src="image/meeting1.jpg" width=125 height=150></a></td>
</tr>
<tr>
	<td><font color="#7c0000">Theatre style</font></td>
	<td></td>
	<td><font color="#7c0000">Causule</font></td>
</tr>
<table>
<br><br>
<table border=1 align=center>
<tr>
	<th>SITTING STYLE</th>
	<th>SITTING CAP.</th>
</tr>
<tr>
	<td>U-SHAPE</td>
	<td>35</td>
</tr>
<tr>
	<td>CLASS ROOM STYLE</td>
	<td>45</td>
</tr>
<tr>
	<td>THEATRE STYLE</td>
	<td>120</td>
</tr>
<tr>
	<td>CASULE</td>
	<td>50</td>
</tr>
</table>
<table>
<tr>
	<td>
	<ul type=square>
	<font size=4 color="#7c0000"><li>Facalities :</font>
	<ul type=disc>
	<font color=darkpink>
	<li>Slide projector
	<li>LCD multimedia projector
	<li>Computer system
	<li>Internet access
	<li>Laser pointer
	<li>White board
	<li>Conference kits
	<li>Background system
	<li>DJ system
	<li>DVD,VCD,CD player
	<li>Telephone & Television
	</ul>
	</ul>
	</td>
</tr>
</table>
<marquee behavior=alternate bgcolor="#7e0000"><b><i><a href=contectus.php><font color="white">Devloped By :- Finava Vipul & Metaliya Nikunj </a></i></b></font></marquee>
</body>
</html>
	
	
	
	