<html>
<body>
	<img src="image/piccolino_hotel_10.jpg" height=488 width=848>
</body>
</html>