<html>
<head>
	<style type="text/css">
	body{background-color:"#fff2e5"}
	th{color:"white";background-color:"chocolate"}
	td{color:"purple";background-color:""}

	a:hover
	{
		color{text-decoration:underline}
	}
	</style>
</head>
</html>