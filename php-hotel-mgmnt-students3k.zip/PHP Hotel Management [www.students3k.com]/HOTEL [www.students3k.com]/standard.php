<html>
<head>
	<title>standard</title>
</head>
<body>
	<center><font color=purple size=6><a href=standard1.php>standard</a></font></center>
	<img src="image/piccolino_hotel_10.jpg" width="858" height=360 width750>
	<font color=purple size=3>
	<pre>
		luxuriously furnished room having a sofa cum bed for an extra adult or child with wall to wall carpet.
	</font>
	</pre>
	<a href=accommodation.php>home</a>
</body>
</html>