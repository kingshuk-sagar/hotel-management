<html>
<body>
	<img src="image/dining1.jpg" height=400 width=750>
</body>
</html>