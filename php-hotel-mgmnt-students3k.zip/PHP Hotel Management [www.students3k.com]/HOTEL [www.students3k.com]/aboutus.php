<html>
<head>
	<title>about us</title>
	<link rel="stylesheet" type="text/css" href="link.php">
</head>
<body bgcolor="#fff3e5">
<form>
<?php
	include "index.php";
?>
<center>
<br><br>
<caption><b><i><u><font color=purple>ABOUT US</u></i></b></font></caption>
</center>
<table width="100%" border=0>
<tr>
	<td>
		<marquee direction="up" align="top" width="175" height="750">
		<img src="image/273-2-zoom-1-aminta-grand-hotel-sorrento-lounge.jpg" height=216 width=587>
		<img src="image/4352_1.jpg" height=200 width=582>
		<img src="image/310042_137777_1156182440.jpg" height=200 width=582>
		<img src="image/caption.jpg" height=200 width=582>
		<img src="image/deluxe07.JPG" height=200 width=582>
		</marquee>	</td>
	<td valign=top><font size=7 color="#7c0000"><b><i>
	<pre>HOTEL PARAS</i></b></font>
	
	ADDRESS		:STATION ROAD,OPP.BUS STATION	
		 	 MAIN RAOD

	CITY		:AMRELI

	STATE		:GUJARAT

	P.O.BOX NO	:20

	PHONE NO.	:+91 990-990-55-10

	E-MAIL		:SALES@SEASONSAMRELI.COM
	</pre>	</td>

	<td>
		<marquee direction="up" align="top" width="175" height="750">
		<img src="image/deluxe07.JPG" height=200 width=750>
		<img src="image/caption.jpg" height=200 width=750>
		<img src="image/310042_137777_1156182440.jpg" height=200 width=750>
		<img src="image/4352_1.jpg" height=200 width=750>
		<img src="image/273-2-zoom-1-aminta-grand-hotel-sorrento-lounge.jpg" height=200 width=750>
      </marquee>	</td>
</table>
<marquee behavior=alternate bgcolor="#7e0000"><b><i><a href=contectus.php><font color="white">Devloped By :- Finava Vipul & Metaliya Nikunj </a></i></b></font></marquee>
</body>
</html>
		
</html>