<html>
<head>
	<title>room</title>
</head>
<body>
<center>
	<a href=suite1.php>Suite	|<a/>
	<a href=superdeluxe1.php>Superdeluxe	|</a>
	<a href=deluxe1.php>Deluxe	|</a>
	<a href=standard1.php>Standard</a></center>
</body>
</html>